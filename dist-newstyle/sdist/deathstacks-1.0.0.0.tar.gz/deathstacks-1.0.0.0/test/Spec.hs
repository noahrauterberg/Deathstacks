import Test.Hspec
import Board
-- #############################################################################
-- ####### YOUR UNIT TESTS                                           ###########
-- ####### Note: execute tests using "stack test deathstacks:units"  ###########
-- #############################################################################

testValidate :: Spec
testValidate = describe "Testing the validation of FEN strings" $ do
        it "test start position" $
            validateFEN "rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb" `shouldBe`  True
        it "test random position" $
            validateFEN "rr,,,,,rr/,,,,,/,bbr,rr,,rrb,/,,,,,/,,,,,/bb,bb,,,bbrrrb,bb" `shouldBe` True
        it "test empty string" $
            validateFEN "" `shouldBe` False
        it "test empty position" $
            validateFEN ",,,,,/,,,,,/,,,,,/,,,,,/,,,,,/,,,,," `shouldBe` True
        it "test only five rows with ending /" $
            validateFEN "rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/" `shouldBe` False
        it "test only five rows without ending /" $
            validateFEN "rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,," `shouldBe` False
        it "test seven rows with ending /" $
            validateFEN ",,,,,/,,,,,/,,,,,/,,,,,/,,,,,/,,,,,/,,,,,/" `shouldBe` False
        it "test seven rows without ending /" $
            validateFEN ",,,,,/,,,,,/,,,,,/,,,,,/,,,,,/,,,,,/,,,,," `shouldBe` False
        it "test seven coloums" $
            validateFEN ",,,,,,/,,,,,,/,,,,,,/,,,,,,/,,,,,,/,,,,,," `shouldBe` False
        it "test only five coloums" $
            validateFEN ",,,,/,,,,/,,,,/,,,,/,,,,/,,,," `shouldBe` False
        it "test wrong characters" $
            validateFEN "gg,,,,,gg/,,,,,/,bbr,rr,,rrb,/,,,,,/,,,,,/bb,bb,,,bbrrrb,bb" `shouldBe` False

sampleBoard :: Board
sampleBoard = [[Stack [Red,Red], Stack [Red,Red], Stack [Red,Red], Stack [Red,Red], Stack [Red,Red], Stack [Red,Red]], [Empty,Empty,Empty,Empty,Empty,Empty], [Empty,Empty,Empty,Empty,Empty,Empty],[Empty,Empty,Empty,Empty,Empty,Empty],[Empty,Empty,Empty,Empty,Empty,Empty],[Stack [Blue,Blue],Stack [Blue,Blue],Stack [Blue,Blue],Stack [Blue,Blue],Stack [Blue,Blue],Stack [Blue,Blue]]]

testBuildBoard :: Spec
testBuildBoard = describe "Testing board building" $ do
    it "test start position" $
        buildBoard "rr,rr,rr,rr,rr,rr/,,,,,/,,,,,/,,,,,/,,,,,/bb,bb,bb,bb,bb,bb" `shouldBe` sampleBoard

main :: IO ()
main = hspec $ do 
    testValidate
    testBuildBoard