module Board where  -- do NOT CHANGE export of module

-- IMPORTS HERE
-- Note: Imports allowed that DO NOT REQUIRE ANY CHANGES TO package.yaml, e.g.:
--       import Data.Chars
import Data.List.Split

-- #############################################################################
-- ############# GIVEN IMPLEMENTATION                           ################
-- ############# Note: "deriving Show" may be deleted if needed ################
-- #############       Given data types may NOT be changed      ################
-- #############################################################################

-- TODO: Remove 
data Move = Move {start :: Pos, target :: Pos, steps :: Int}
-- end

data Player = Red | Blue deriving Show
data Cell =  Stack [Player] | Empty deriving Show
data Pos = Pos { col :: Char, row :: Int } deriving Show
data Dir = North | NorthEast | East | SouthEast | South | SouthWest | West | NorthWest deriving Show
type Board = [[Cell]]

instance Eq Pos where
  (==) (Pos c1 r1) (Pos c2 r2) = (c1 == c2) && (r1 == r2)

instance Eq Player where
  (==) Blue Blue = True
  (==) Red Red = True
  (==) _ _ = False

instance Eq Cell where
  (==) Empty Empty = True
  (==) (Stack xs) (Stack ys) = xs == ys
  (==) _ _ = False


-- #############################################################################
-- ################# IMPLEMENT validateFEN :: String -> Bool ###################
-- ################## - 2 Functional Points                  ###################
-- ################## - 1 Coverage Point                     ###################
-- #############################################################################


-- Anforderungen:
-- 6 Reihen
-- 6 Spalten
-- nur 'r' und 'b'
-- nicht: insgesamt 24 Figuren
-- nicht: maximal 2 Stapel der Höhe > 4
-- -> pattern matching string
validateFEN :: String -> Bool
validateFEN x = validateHelp x 0 0

validateHelp :: String -> Int -> Int -> Bool
validateHelp "" reihe spalte = reihe == 5 && spalte == 5
validateHelp (x:xs) reihe spalte = case x of
  'r' -> validateHelp xs reihe spalte
  'b' -> validateHelp xs reihe spalte
  ',' -> validateHelp xs reihe (spalte + 1)
  '/' -> (spalte == 5) && validateHelp xs (reihe + 1) 0
  _ -> False

-- #############################################################################
-- ####################### buildBoard :: String -> Board #######################
-- ####################### - 2 Functional Points         #######################
-- ####################### - 1 Coverage Point            #######################
-- #############################################################################

buildBoard :: String -> Board
buildBoard x = buildHelp (splitOn "/" x)

-- buildStack :: String -> [Player] -> [Player]
-- buildStack (x:xs) curStack = case x of
--   'r' -> buildStack xs (curStack ++ [Red])
--   'b' -> buildStack xs (curStack ++ [Blue])
--   _ -> curStack

-- building the board by calling buildRow six times
buildHelp :: [String] -> Board
buildHelp [] = []
buildHelp (x:xs) = buildRow x [] [] : buildHelp xs

-- buildHelp :: String -> [[Cell]] -> [Cell] -> [[Cell]]
-- buildHelp "" curBoard _ = curBoard
-- buildHelp (x:xs) curBoard curRow = case x of
--   '/' -> curBoard

-- initial: buildRow string [] []
-- building each row seperately
buildRow :: String -> [Cell] -> [Player] -> [Cell]
buildRow "" curRow _ = curRow
buildRow (x:xs) curRow curStack = case x of
  'r' -> buildRow xs curRow (curStack ++ [Red])
  'b' -> buildRow xs curRow (curStack ++ [Blue])
  ',' -> buildRow xs (curRow ++ [Stack curStack]) []
  -- ',' -> if curStack == [] then buildRow xs ()

-- buildHelp :: String -> Board -> [Cell] -> [Player] -> Int -> Board
-- buildHelp (x:xs) curBoard curRow curStack index = case x of
--   'r' -> buildHelp xs curBoard curRow (curStack ++ [Red]) index
--   'b' -> buildHelp xs curBoard curRow (curStack ++ [Blue]) index
--   ',' -> buildHelp xs curBoard (curRow ++ [Stack curStack]) [] index
--   '/' -> buildHelp xs (curBoard ++ [curRow]) [] [] (index + 1)
--   _ -> curBoard

-- #############################################################################
-- #################### path :: Pos -> Dir -> Int -> [Pos]  ####################
-- #################### - 4 Functional Points               ####################
-- #################### - 1 Coverage Point                  ####################
-- #############################################################################

path :: Pos -> Dir -> Int -> [Pos]
path _ _ _ = []