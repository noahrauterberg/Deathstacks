module Main (main) where


main :: IO ()
main = print "This will be out bot later!"